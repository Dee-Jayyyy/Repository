from flask import Flask, request, jsonify
from transformers import pipeline

app = Flask(__name__)
classifier = pipeline("sentiment-analysis")

@app.route('/evaluate', methods=['POST'])
def evaluate():
    insult = request.json['insult']
    result = classifier(insult)
    score = result[0]['score'] if result[0]['label'] == 'NEGATIVE' else 1 - result[0]['score']
    return jsonify({'score': score})

if __name__ == '__main__':
    app.run(port=5000)
